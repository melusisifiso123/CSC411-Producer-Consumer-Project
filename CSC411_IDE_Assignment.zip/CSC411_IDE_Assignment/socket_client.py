
import socket
from producer_consumer import ITStudent

c=socket.socket(); c.connect(("localhost",5000))

while True:
    d=c.recv(4096)
    if not d: break
    open("recv.xml","w").write(d.decode())
    s=ITStudent.from_xml("recv.xml")
    avg=sum(s.courses.values())/len(s.courses)
    print("[SOCKET]",s.name,s.student_id,avg)
