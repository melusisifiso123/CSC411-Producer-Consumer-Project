
import random, xml.etree.ElementTree as ET, threading, time, os

class ITStudent:
    def __init__(self):
        self.name = random.choice(["Melusi Dlamini","Nomvuselelo Msibi","Zamo Tsabedze"])
        self.student_id = "".join([str(random.randint(0,9)) for _ in range(8)])
        self.programme = random.choice(["BSc Computer Science Edu","BSc IT"])
        self.courses = {
            "Programming": random.randint(40,100),
            "Networking": random.randint(40,100),
            "Database": random.randint(40,100)
        }
    def to_xml(self,f):
        root=ET.Element("ITStudent")
        ET.SubElement(root,"Name").text=self.name
        ET.SubElement(root,"ID").text=self.student_id
        ET.SubElement(root,"Programme").text=self.programme
        c_el=ET.SubElement(root,"Courses")
        for k,v in self.courses.items():
            el=ET.SubElement(c_el,"Course",name=k); el.text=str(v)
        ET.ElementTree(root).write(f)

    @staticmethod
    def from_xml(f):
        t=ET.parse(f); r=t.getroot()
        s=ITStudent()
        s.name=r.find("Name").text
        s.student_id=r.find("ID").text
        s.programme=r.find("Programme").text
        s.courses={c.attrib["name"]:int(c.text) for c in r.find("Courses")}
        return s

BUFFER_SIZE=10
buffer=[]
empty=threading.Semaphore(BUFFER_SIZE)
full=threading.Semaphore(0)
mutex=threading.Semaphore(1)

def producer():
    for i in range(1,11):
        empty.acquire(); mutex.acquire()
        s=ITStudent()
        f=f"student{i}.xml"; s.to_xml(f)
        buffer.append(i)
        print("[PRODUCER] Wrote",f)
        mutex.release(); full.release(); time.sleep(1)

def consumer():
    while True:
        full.acquire(); mutex.acquire()
        if not buffer:
            mutex.release(); continue
        n=buffer.pop(0)
        f=f"student{n}.xml"
        s=ITStudent.from_xml(f)
        avg=sum(s.courses.values())/len(s.courses)
        print("\n[CONSUMER REPORT]")
        print("Name:",s.name,"ID:",s.student_id,"Avg:",avg)
        os.remove(f)
        mutex.release(); empty.release(); time.sleep(1)

if __name__=="__main__":
    t1=threading.Thread(target=producer)
    t2=threading.Thread(target=consumer)
    t1.start(); t2.start(); t1.join()
