
import socket, time
from producer_consumer import ITStudent

s=socket.socket()
s.bind(("localhost",5000)); s.listen(1)
c,addr=s.accept()

for i in range(1,6):
    st=ITStudent(); f=f"sock{i}.xml"; st.to_xml(f)
    c.send(open(f).read().encode()); time.sleep(1)
c.close()
