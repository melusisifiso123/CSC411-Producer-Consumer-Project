
# CSC411 Producer Consumer Project
Includes:
- Producer/Consumer with semaphores
- XML wrapping/unwrapping
- Socket programming
- PDF report
